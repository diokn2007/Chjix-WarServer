import {
  readFileSync,
  writeFileSync,
  existsSync,
  statSync
} from 'fs';
import {
  spawn,
  execSync
} from 'child_process';
import semver from 'semver';
import axios from 'axios';
import {} from 'dotenv/config';
import logger from './System/Core/helpers/console.js';
import loadPlugins from './System/Core/helpers/installDep.js';
import environments from './System/Core/helpers/environments.get.js';
import gradient from 'gradient-string';
import Banner from './System/Banner.js';
import Active from './System/Active.js';
const _1_MINUTE = 60000;
let restartCount = 0;
console.clear();
async function main() {
    await Banner();
    await notification();
    await Active();
    await update();
    const _0x8239x4 = spawn('node', ['--trace-warnings', '--experimental-import-meta-resolve', '--expose-gc', 'System/Chjix-War.js'], {
        cwd: process.cwd(),
        stdio: 'inherit',
        env: process.env
    });
    _0x8239x4.on('close', async (_0x8239x5) => {
        handleRestartCount();
        if (_0x8239x5 !== 0 && restartCount < 5) {
            console.log();
            logger.error("Lỗi khởi động xảy ra Lỗi: " + _0x8239x5);
            logger.warn('Đang khởi động lại...');
            await new Promise((_0x8239x6) => {
                return setTimeout(_0x8239x6, 2000)
            });
            main()
        } else {
            logger.error('Chjix-War đã tự động dừng...');
            process.exit()
        }
    })
}
async function notification() {
    try {
        const _0x8239x8 = await axios.get('https://raw.githubusercontent.com/diokn2007/Chjix-WarServer/main/notification.json');
        console.log(gradient.retro("ㄴ==========THÔNG BÁO==========ㄴ"));
        const notification = _0x8239x8.data.notification;
        notification.forEach((_0x8239x9) => {
            console.log("› " + _0x8239x9)
        });
        console.log(gradient.retro("==========================================\n"))
    } catch (e) {
        logger.warn('Không thể kết nối tới máy chủ thông báo')
    }
}
async function update() {
    try {
        const _0x8239xb = await axios.get('https://raw.githubusercontent.com/diokn2007/Chjix-WarServer/main/package.json');
        const {
            version
        } = _0x8239xb.data;
        const _0x8239xc = JSON.parse(readFileSync('./package.json')).version;
        if (semver.lt(_0x8239xc, version)) {
            logger.warn("Đã có phiên bản mới: " + version);
            logger.warn("Phiên bản hiện tại: " + _0x8239xc);
            logger.error('Vui lòng cập nhật lên phiên bản mới nhất để sử dụng bot')
        } else {
            logger.custom('Bạn đang sử dụng phiên bản mới nhất của Chjix-War rồi.', 'UPDATE')
        }
    } catch (err) {
        logger.error('Không thể kết nối tới máy chủ cập nhật.')
    }
}

function handleRestartCount() {
    restartCount++;
    setTimeout(() => {
        restartCount--
    }, _1_MINUTE)
}
main()