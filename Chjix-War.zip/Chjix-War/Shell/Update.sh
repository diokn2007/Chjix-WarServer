clear
echo "Đang tiến hành cập nhật cho Gbot War..."
sleep 3
node updater
