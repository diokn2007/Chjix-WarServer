#! /bin/bash
clear

node nguyenblue