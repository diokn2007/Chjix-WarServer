#! /bin/bash
clear

node active
