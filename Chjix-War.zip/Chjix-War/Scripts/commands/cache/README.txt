all files here will be removed when starting bot
