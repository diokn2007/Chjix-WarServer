import axios from 'axios';
import { resolve as resolvePath } from 'path';
import { readFileSync } from 'fs';
import logger from './Core/helpers/console.js';

const config = JSON.parse(readFileSync(resolvePath(process.cwd(), 'Config', 'config.main.json')));

async function checkActive() {
    try {
        const url = 'https://raw.githubusercontent.com/Chjix-WarServer/main/ACTIVE/' + config.GBOTWAR_OPTIONS.KEY_ACTIVE + '.json';
        const response = await axios.get(url);
        const data = response.data;
        
        if (data.status === false) {
            logger.error('Key của bạn đã bị tắt hoặc không còn thời gian sử dụng, Vui lòng liên hệ admin để biết thêm chi tiết');
            process.exit();
        } else {
            if (data.lock === true) {
                logger.error('Bạn đã bị cấm sử dụng bot, Mọi thắc mắc vui lòng liên hệ admin nguyên blue');
            } else {
                logger.info('Xin chào ' + data.name + ' cảm ơn đã sử dụng bot của nguyên blue');
                logger.info('Key của bạn được kích hoạt vào: ' + data.time);
                logger.info('Email liên hệ của bạn là: ' + data.email);
            }
        }
    } catch (e) {
        logger.error('Đây là phiên bản Chjix-War trả phí vui lòng liên hệ admin để mua');
        logger.error('Liên hệ admin nguyên blue để kích hoạt');
        process.exit();
    }
}

export default checkActive;